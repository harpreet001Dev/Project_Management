import React from 'react'

const Unauth = () => {
  return (
    <div>Unauth</div>
  )
}

export default Unauth